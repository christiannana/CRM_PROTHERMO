import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menuoption',
  templateUrl: './menuoption.component.html',
  styleUrls: ['./menuoption.component.css']
})
export class MenuoptionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
