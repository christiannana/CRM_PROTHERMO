import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-ajout-client',
//   templateUrl: './ajout-client.component.html',
//   styleUrls: ['./ajout-client.component.css']
// })
// export class AjoutClientComponent implements OnInit {

//   constructor() { }

//   ngOnInit(): void {
//   }

// }
