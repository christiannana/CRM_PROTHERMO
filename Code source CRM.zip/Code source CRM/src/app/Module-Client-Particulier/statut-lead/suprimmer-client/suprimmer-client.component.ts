import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-suprimmer-client',
  templateUrl: './suprimmer-client.component.html',
  styleUrls: ['./suprimmer-client.component.css']
})
export class SuprimmerClientComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
