import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fiche-client-regie',
  templateUrl: './fiche-client-regie.component.html',
  styleUrls: ['./fiche-client-regie.component.css']
})
export class FicheClientRegieComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
