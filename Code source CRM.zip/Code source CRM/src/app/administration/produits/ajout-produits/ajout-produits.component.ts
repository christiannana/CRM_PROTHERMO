import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-ajout-produits',
//   templateUrl: './ajout-produits.component.html',
//   styleUrls: ['./ajout-produits.component.css']
// })
// export class AjoutProduitsComponent implements OnInit {

//   constructor() { }

//   ngOnInit(): void {
//   }

// }
