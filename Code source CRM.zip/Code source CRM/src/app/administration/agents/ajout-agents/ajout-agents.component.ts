import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-ajout-agents',
//   templateUrl: './ajout-agents.component.html',
//   styleUrls: ['./ajout-agents.component.css']
// })
// export class AjoutAgentsComponent implements OnInit {

//   constructor() { }

//   ngOnInit(): void {
//   }

// }
