import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detail-aide',
  templateUrl: './detail-aide.component.html',
  styleUrls: ['./detail-aide.component.css']
})
export class DetailAideComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
