import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ModuleProfessionnelRoutingModule } from './module-professionnel-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ModuleProfessionnelRoutingModule
  ]
})
export class ModuleProfessionnelModule { }
